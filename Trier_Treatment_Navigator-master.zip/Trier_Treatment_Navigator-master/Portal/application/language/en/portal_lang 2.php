<?php
/*
*
* Sprache: Englisch
* Controller: controllers/portal.php
* 
*
* @author Ruven Martin
* @since 0.8.0 
*/
$lang['sessions'] = 'Sessions';
$lang['portal_therapeut'] = 'Portal (Therapeut)';
$lang['portal_patient'] = 'Portal (Patient)';
$lang['portal_admin'] = 'Portal (Admin/<br/>Supervisor)';
$lang['rooms'] = 'Rooms';
