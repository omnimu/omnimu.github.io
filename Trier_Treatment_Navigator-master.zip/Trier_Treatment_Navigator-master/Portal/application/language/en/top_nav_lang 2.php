<?php
/*
* 
* Views: views\<every user role>\top_nav.php
* 
*/

$lang['profile'] = 'My profile';