<?php

/*
*
* View: views\user\patient\process.php
*
*/

$lang['therapy_all'] = 'Show all (default)';
$lang['therapy_single_exclude'] = 'Singletherapy';
$lang['therapy_group'] = 'Grouptherapy';
$lang['therapy_online'] = 'Onlinetherapy';
$lang['therapy_seminar'] = 'Seminartherapy';
$lang['no_therapy_graph_data'] = 'The applied filter filtered out all data and therefore no graph could be drawn';
