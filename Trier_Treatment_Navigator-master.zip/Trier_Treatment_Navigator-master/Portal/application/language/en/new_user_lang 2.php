<?php

/*
*
* View: views\admin\user\new_user.php
*
*/

$lang['password_strength'] = 'Password strength';
$lang['password_too_weak'] = 'Password too weak.';
$lang['passwords_not_matching'] = 'Passwords are not matching.';
