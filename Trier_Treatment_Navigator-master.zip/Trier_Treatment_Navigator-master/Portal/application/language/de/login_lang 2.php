<?php
/*
*
* Sprache: Englisch
* Controller: controllers/login.php
* 
*
* @author Ruven Martin
* @since 0.8.0 
*/
$lang['username'] = 'Benutzername';
$lang['password'] = 'Passwort';
