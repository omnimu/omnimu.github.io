<?php

/*
*
* View: views\admin\user\new_user.php
*
*/

$lang['password_strength'] = 'Passwort Stärke';
$lang['password_too_weak'] = 'Das Passwort ist zu schwach.';
$lang['passwords_not_matching'] = 'Passwörter stimmen nicht überein.';
